//============================================================================
// Name        : project3_Knighton_kmk0120.cpp
// Author      : Katie Knighton kmk0120
// References  : cplusplus.com/reference/algorithm/sort/ for sorting vector 3
// 			   : cplusplus.com/doc/tutorial/files/ for writing to a file
//             : https://stackoverflow.com/questions/20636914/c-mean-median-and-mode
//             : https://stackoverflow.com/questions/19920542/c-calculating-the-mode-of-a-sorted-array
//             : https://stackoverflow.com/questions/1232040/how-do-i-empty-an-array-in-javascript
//  
//============================================================================

#include <fstream>
#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

const int MAX_SIZE = 100;

int readfile(int* ptr, ifstream& instream);
int sort(int numFiles, int** fileArrays, int* fileSizes, int* out);
void writefile(int outputArray[], int outputArray_size, string output_filename);



int main() {

    int numFiles;

    cout << "*** Welcome to Katie's sorting program ***" << endl;
    cout << "Enter the number of files to read: ";
    cin >> numFiles;

    string* filenames = new string[numFiles];
    int* fileSizes = new int[numFiles];
    int** fileArrays = new int*[numFiles];
    for(int i=0; i<numFiles; i++) {
        fileArrays[i] = new int[MAX_SIZE];
    }

    int* output_array = new int[numFiles * MAX_SIZE];
    int output_size;

    ifstream inStream;



    for(int idx = 0; idx < numFiles; idx++) {
        cout << "Enter the name of input file " << idx+1 << ": ";
        cin >> filenames[idx];

        if(filenames[idx] == "quit") {
            cout << "Input cancelled, Proceeding to calculation..." << endl;
            if(idx == 0) {
                cout << "\n*** Goodbye. ***" << endl;
                return 0;
            }
            numFiles = idx;
            break;
        }

        inStream.open((char*)filenames[idx].c_str());
        fileSizes[idx] = readfile(fileArrays[idx], inStream);
        inStream.close();

        cout << "The list of " << fileSizes[idx] << " numbers in " << filenames[idx] << " is:" << endl;
        for(int jdx=0; jdx<fileSizes[idx]; jdx++) {
            cout << fileArrays[idx][jdx] << endl;
        }
    }

    output_size = sort(numFiles, fileArrays, fileSizes, output_array);

    cout << "\nThe sorted list of " << output_size << " numbers is : ";
    for(int i=0; i<output_size; i++) {
        cout << output_array[i] << " ";
    }

    string output_filename;
    cout << "\nEnter the output file name: ";
    cin >> output_filename;
    
    writefile(output_array, output_size, output_filename);

    cout << "*** Please check the new file - " << output_filename << " ***" << endl << "*** Goodbye. ***";

    return 0;
}

int readfile(int* ptr, ifstream& inStream) {
    int size = 0;
    string data;
    
    while(getline(inStream, data)) {

        //converts string to int
        int temp = 0;
        bool neg = false;
        for(int i=0; i<data.length(); i++) {
            if(data[i] == '-') {
                neg = true;
            }

            else if(!isdigit(data[i])) {
                continue;
            }
            
            else {
                temp *= 10;
                temp += (int)data[i]-48;
            }
        }

        neg ? *(ptr + size) = (-1)*temp : *(ptr + size) = temp;

        size++;
    }

    return size;
}

int sort(int numFiles, int** fileArrays, int* fileSizes, int* out) {

    int outputArray_size = 0;

    for(int idx = 0; idx < numFiles; idx++) {
        for(int jdx = 0; jdx < fileSizes[idx]; jdx++) {
            out[outputArray_size] = fileArrays[idx][jdx];
            outputArray_size++;
        }
    }

    //sort the array
    int temp;

    //bubble sort
    for(int i = 0; i<outputArray_size; i++) {
        for(int j = i+1; j<outputArray_size; j++) {
            if(out[j] < out[i]) {
                temp = out[i];
                out[i] = out[j];
                out[j] = temp;
            }
        }
    }
    
    return outputArray_size;
}

void writefile(int outputArray[], int outputArray_size, string output_filename) {
    ofstream outStream((char*)output_filename.c_str());

    for(int i=0; i<outputArray_size; i++) {
        outStream << outputArray[i] << endl;
    }

    outStream.close();

}